package cts.g1082.popescu.mihaela.patternStrategy;

public class StrategieAnunturiInformative implements IAnunturi {

    @Override
    public String getAnunt() {
        return "Se aduce la cunostinta ";
    }
}
