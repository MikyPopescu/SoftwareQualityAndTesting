package cts.g1082.popescu.mihaela.patternStrategy;

public class StrategieAnunturiAngajare implements IAnunturi {

    @Override
    public String getAnunt() {
        return "Se angajeaza ";
    }
}
