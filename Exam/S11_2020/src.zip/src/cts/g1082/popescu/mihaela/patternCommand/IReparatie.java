package cts.g1082.popescu.mihaela.patternCommand;

public interface IReparatie {
    public void executaReparatie();
}
