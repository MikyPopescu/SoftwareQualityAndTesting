package cts.g1082.popescu.mihaela.patternCommand;

public class ModulInstalatori implements  IReparatie{
    @Override
    public void executaReparatie() {
        System.out.println("A rezolvat instalatorul");
    }
}
