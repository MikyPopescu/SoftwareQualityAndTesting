package cts.g1082.popescu.mihaela.patternStrategy;

public interface IAnunturi {
    public String getAnunt();
}
