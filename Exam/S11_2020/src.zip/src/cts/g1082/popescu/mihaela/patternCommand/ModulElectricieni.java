package cts.g1082.popescu.mihaela.patternCommand;

public class ModulElectricieni implements IReparatie{
    @Override
    public void executaReparatie() {
        System.out.println("A rezolvat electricianul");
    }
}
