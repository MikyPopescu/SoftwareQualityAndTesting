package cts.g1082.popescu.mihaela.command;

public enum Operatiune {
    VANZARE,
    CUMPARARE
}
