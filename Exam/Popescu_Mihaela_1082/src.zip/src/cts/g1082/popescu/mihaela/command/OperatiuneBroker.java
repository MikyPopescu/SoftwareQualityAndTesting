package cts.g1082.popescu.mihaela.command;

public interface OperatiuneBroker {
    public void executa();

}
