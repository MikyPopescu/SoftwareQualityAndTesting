package cts.g1082.popescu.mihaela.command;

public class TestCommand {
    public static void main(String[] args) {
        Client c = new Client("Mircea");

        Platforma p = new Platforma();
    }
}
