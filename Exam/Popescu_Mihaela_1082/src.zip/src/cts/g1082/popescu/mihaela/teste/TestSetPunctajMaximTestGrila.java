package cts.g1082.popescu.mihaela.teste;

import cts.g1082.popescu.mihaela.TestGrila;
import cts.g1082.popescu.mihaela.exceptii.ExceptiePunctajInvalid;
import cts.g1082.popescu.mihaela.teste.suita.TestSuiteCategory;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class TestSetPunctajMaximTestGrila {

}