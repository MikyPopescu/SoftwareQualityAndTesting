package cts.g1082.popescu.mihaela.teste.suita;

public class TestSuiteCategory {
}
