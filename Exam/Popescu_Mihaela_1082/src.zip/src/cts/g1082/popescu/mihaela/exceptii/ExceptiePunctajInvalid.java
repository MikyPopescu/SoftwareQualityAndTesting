package cts.g1082.popescu.mihaela.exceptii;

public class ExceptiePunctajInvalid extends Exception {
}
