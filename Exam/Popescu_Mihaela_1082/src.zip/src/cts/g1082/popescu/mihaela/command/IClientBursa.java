package cts.g1082.popescu.mihaela.command;


public interface IClientBursa {
    public void vinde(String codActiuni, int nrActiuni);
    public void cumpara(String codActiuni, int nrActiuni);
}
