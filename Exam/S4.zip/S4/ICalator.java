package pck;

public interface ICalator {

	void deplaseaza(int numarKm);
	
}
