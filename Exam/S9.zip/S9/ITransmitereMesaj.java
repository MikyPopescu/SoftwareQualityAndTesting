
public interface ITransmitereMesaj {
	public void primireMesaj(String user, String mesaj);
}
