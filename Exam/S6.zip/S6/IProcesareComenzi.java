

//utila pentru cerinta 2 a subiectului
public interface IProcesareComenzi {
	public void procesareComanda(String detalii, int nrProduse, float valoareTotala);
}
