
public interface IGlovo {
	public void getListaCumparaturi(String listaCumparaturi);
}
