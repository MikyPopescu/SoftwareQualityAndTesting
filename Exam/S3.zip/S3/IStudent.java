package pck;

public interface IStudent {
	
	void sustineExamen(String displina);

}
